function readSingleFile(e) {
    var file = e.target.files[0];
    if (!file) {
        return;
    }
    var reader = new FileReader();
    reader.onload = function (e) {
        var contents = e.target.result;
        console.log(contents)
        main(contents)
    };
    reader.readAsText(file);
}

window.onload = function () {
    document.getElementById('file-input')
        .addEventListener('change', readSingleFile, false);
};

function main(text) {
    parser = new DOMParser();
    xml = parser.parseFromString(text, "text/xml")

    console.log(typeof xml)
    //path = '/teryt/catalog/row[NAZWA_DOD[text()]="województwo"]/NAZWA'
    path = 'teryt/catalog/row[NAZWA_DOD[text()]="województwo"]/NAZWA/text()'
    output = xml.evaluate(path, xml, null, XPathResult.ANY_TYPE, null).iterateNext().childNodes
    console.log(output)
}